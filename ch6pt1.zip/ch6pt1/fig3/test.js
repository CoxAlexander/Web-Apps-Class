var mod1 = require("module1"); //"module1" is the directory name
console.log("mod1 =", mod1);