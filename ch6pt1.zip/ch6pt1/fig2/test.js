var mod1 = require("module1.js");  // or require("module1")
console.log("mod1 =", mod1);