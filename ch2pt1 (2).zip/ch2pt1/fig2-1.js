class Person{
}
var p = new Person;
console.log(p);