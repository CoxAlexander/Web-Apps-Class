class Person {
  firstname;
  lastname;
  age;
}
var p = new Person;
console.log(p);