const Element = {
  data() {
    return {
    }
  },
  template : `
  `,
}
export default Element;