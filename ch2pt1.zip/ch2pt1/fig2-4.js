class Person {
  firstname = "";
  lastname = "";
  age = 0;
}
var p = new Person;
console.log(p);