var tab = new Array();    // or new Array;
console.log(tab);