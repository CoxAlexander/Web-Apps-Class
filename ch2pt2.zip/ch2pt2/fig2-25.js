var s = new String("I'll love JavaScript");
console.log("s =", s);