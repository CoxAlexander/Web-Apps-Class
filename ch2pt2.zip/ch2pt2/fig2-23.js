var s = 'String 1';
console.log("s =", s);